gdjs.websiteCode = {};
gdjs.websiteCode.localVariables = [];
gdjs.websiteCode.GDTwitterObjects1= [];
gdjs.websiteCode.GDTwitterObjects2= [];
gdjs.websiteCode.GDTwitterObjects3= [];
gdjs.websiteCode.GDTwitterObjects4= [];
gdjs.websiteCode.GDTwitterObjects5= [];
gdjs.websiteCode.GDYoutubeObjects1= [];
gdjs.websiteCode.GDYoutubeObjects2= [];
gdjs.websiteCode.GDYoutubeObjects3= [];
gdjs.websiteCode.GDYoutubeObjects4= [];
gdjs.websiteCode.GDYoutubeObjects5= [];
gdjs.websiteCode.GDwebsite_9595nameObjects1= [];
gdjs.websiteCode.GDwebsite_9595nameObjects2= [];
gdjs.websiteCode.GDwebsite_9595nameObjects3= [];
gdjs.websiteCode.GDwebsite_9595nameObjects4= [];
gdjs.websiteCode.GDwebsite_9595nameObjects5= [];
gdjs.websiteCode.GDsteamObjects1= [];
gdjs.websiteCode.GDsteamObjects2= [];
gdjs.websiteCode.GDsteamObjects3= [];
gdjs.websiteCode.GDsteamObjects4= [];
gdjs.websiteCode.GDsteamObjects5= [];
gdjs.websiteCode.GDBody_95951Objects1= [];
gdjs.websiteCode.GDBody_95951Objects2= [];
gdjs.websiteCode.GDBody_95951Objects3= [];
gdjs.websiteCode.GDBody_95951Objects4= [];
gdjs.websiteCode.GDBody_95951Objects5= [];
gdjs.websiteCode.GDtext_9595body_9595referenceObjects1= [];
gdjs.websiteCode.GDtext_9595body_9595referenceObjects2= [];
gdjs.websiteCode.GDtext_9595body_9595referenceObjects3= [];
gdjs.websiteCode.GDtext_9595body_9595referenceObjects4= [];
gdjs.websiteCode.GDtext_9595body_9595referenceObjects5= [];
gdjs.websiteCode.GDmenu_9595buttonObjects1= [];
gdjs.websiteCode.GDmenu_9595buttonObjects2= [];
gdjs.websiteCode.GDmenu_9595buttonObjects3= [];
gdjs.websiteCode.GDmenu_9595buttonObjects4= [];
gdjs.websiteCode.GDmenu_9595buttonObjects5= [];
gdjs.websiteCode.GDtemplateObjects1= [];
gdjs.websiteCode.GDtemplateObjects2= [];
gdjs.websiteCode.GDtemplateObjects3= [];
gdjs.websiteCode.GDtemplateObjects4= [];
gdjs.websiteCode.GDtemplateObjects5= [];
gdjs.websiteCode.GDNewButtonObjects1= [];
gdjs.websiteCode.GDNewButtonObjects2= [];
gdjs.websiteCode.GDNewButtonObjects3= [];
gdjs.websiteCode.GDNewButtonObjects4= [];
gdjs.websiteCode.GDNewButtonObjects5= [];
gdjs.websiteCode.GDsingle_9595lineObjects1= [];
gdjs.websiteCode.GDsingle_9595lineObjects2= [];
gdjs.websiteCode.GDsingle_9595lineObjects3= [];
gdjs.websiteCode.GDsingle_9595lineObjects4= [];
gdjs.websiteCode.GDsingle_9595lineObjects5= [];
gdjs.websiteCode.GDmenu_9595backingObjects1= [];
gdjs.websiteCode.GDmenu_9595backingObjects2= [];
gdjs.websiteCode.GDmenu_9595backingObjects3= [];
gdjs.websiteCode.GDmenu_9595backingObjects4= [];
gdjs.websiteCode.GDmenu_9595backingObjects5= [];
gdjs.websiteCode.GDclipboard_9595iconObjects1= [];
gdjs.websiteCode.GDclipboard_9595iconObjects2= [];
gdjs.websiteCode.GDclipboard_9595iconObjects3= [];
gdjs.websiteCode.GDclipboard_9595iconObjects4= [];
gdjs.websiteCode.GDclipboard_9595iconObjects5= [];
gdjs.websiteCode.GDtransition_9595screenObjects1= [];
gdjs.websiteCode.GDtransition_9595screenObjects2= [];
gdjs.websiteCode.GDtransition_9595screenObjects3= [];
gdjs.websiteCode.GDtransition_9595screenObjects4= [];
gdjs.websiteCode.GDtransition_9595screenObjects5= [];
gdjs.websiteCode.GDflex_9595containerObjects1= [];
gdjs.websiteCode.GDflex_9595containerObjects2= [];
gdjs.websiteCode.GDflex_9595containerObjects3= [];
gdjs.websiteCode.GDflex_9595containerObjects4= [];
gdjs.websiteCode.GDflex_9595containerObjects5= [];
gdjs.websiteCode.GDemail_9595clipboardObjects1= [];
gdjs.websiteCode.GDemail_9595clipboardObjects2= [];
gdjs.websiteCode.GDemail_9595clipboardObjects3= [];
gdjs.websiteCode.GDemail_9595clipboardObjects4= [];
gdjs.websiteCode.GDemail_9595clipboardObjects5= [];
gdjs.websiteCode.GDphone_9595clipboardObjects1= [];
gdjs.websiteCode.GDphone_9595clipboardObjects2= [];
gdjs.websiteCode.GDphone_9595clipboardObjects3= [];
gdjs.websiteCode.GDphone_9595clipboardObjects4= [];
gdjs.websiteCode.GDphone_9595clipboardObjects5= [];
gdjs.websiteCode.GDNewPosterObjects1= [];
gdjs.websiteCode.GDNewPosterObjects2= [];
gdjs.websiteCode.GDNewPosterObjects3= [];
gdjs.websiteCode.GDNewPosterObjects4= [];
gdjs.websiteCode.GDNewPosterObjects5= [];
gdjs.websiteCode.GDNewhamburger_9595menuObjects1= [];
gdjs.websiteCode.GDNewhamburger_9595menuObjects2= [];
gdjs.websiteCode.GDNewhamburger_9595menuObjects3= [];
gdjs.websiteCode.GDNewhamburger_9595menuObjects4= [];
gdjs.websiteCode.GDNewhamburger_9595menuObjects5= [];
gdjs.websiteCode.GDpress_9595basic_9595infoObjects1= [];
gdjs.websiteCode.GDpress_9595basic_9595infoObjects2= [];
gdjs.websiteCode.GDpress_9595basic_9595infoObjects3= [];
gdjs.websiteCode.GDpress_9595basic_9595infoObjects4= [];
gdjs.websiteCode.GDpress_9595basic_9595infoObjects5= [];
gdjs.websiteCode.GDMediaObjects1= [];
gdjs.websiteCode.GDMediaObjects2= [];
gdjs.websiteCode.GDMediaObjects3= [];
gdjs.websiteCode.GDMediaObjects4= [];
gdjs.websiteCode.GDMediaObjects5= [];
gdjs.websiteCode.GDloadscreenObjects1= [];
gdjs.websiteCode.GDloadscreenObjects2= [];
gdjs.websiteCode.GDloadscreenObjects3= [];
gdjs.websiteCode.GDloadscreenObjects4= [];
gdjs.websiteCode.GDloadscreenObjects5= [];
gdjs.websiteCode.GDthrobberObjects1= [];
gdjs.websiteCode.GDthrobberObjects2= [];
gdjs.websiteCode.GDthrobberObjects3= [];
gdjs.websiteCode.GDthrobberObjects4= [];
gdjs.websiteCode.GDthrobberObjects5= [];


gdjs.websiteCode.eventsList0 = function(runtimeScene, asyncObjectsList) {

{


let isConditionTrue_0 = false;
{
{gdjs.evtTools.runtimeScene.createObjectsFromExternalLayout(runtimeScene, "home page", 0, 0, 0);
}{runtimeScene.getScene().getVariables().getFromIndex(2).setString("home");
}}

}


{


let isConditionTrue_0 = false;
{
gdjs.copyArray(runtimeScene.getObjects("loadscreen"), gdjs.websiteCode.GDloadscreenObjects3);
gdjs.copyArray(runtimeScene.getObjects("throbber"), gdjs.websiteCode.GDthrobberObjects3);
{for(var i = 0, len = gdjs.websiteCode.GDloadscreenObjects3.length ;i < len;++i) {
    gdjs.websiteCode.GDloadscreenObjects3[i].getBehavior("Tween").addObjectOpacityTween2("unload", 0, "easeInQuad", 0.25, false);
}
}{for(var i = 0, len = gdjs.websiteCode.GDthrobberObjects3.length ;i < len;++i) {
    gdjs.websiteCode.GDthrobberObjects3[i].getBehavior("Tween").addObjectOpacityTween2("unload", 0, "easeInQuad", 0.25, false);
}
}}

}


};gdjs.websiteCode.asyncCallback10382244 = function (runtimeScene, asyncObjectsList) {
asyncObjectsList.restoreLocalVariablesContainers(gdjs.websiteCode.localVariables);

{ //Subevents
gdjs.websiteCode.eventsList0(runtimeScene, asyncObjectsList);} //End of subevents
gdjs.websiteCode.localVariables.length = 0;
}
gdjs.websiteCode.eventsList1 = function(runtimeScene) {

{


{
{
const asyncObjectsList = new gdjs.LongLivedObjectsList();
asyncObjectsList.backupLocalVariablesContainers(gdjs.websiteCode.localVariables);
runtimeScene.getAsyncTasksManager().addTask(gdjs.evtTools.runtimeScene.wait(0.25), (runtimeScene) => (gdjs.websiteCode.asyncCallback10382244(runtimeScene, asyncObjectsList)));
}
}

}


};gdjs.websiteCode.eventsList2 = function(runtimeScene) {

{


let isConditionTrue_0 = false;
{
gdjs.copyArray(runtimeScene.getObjects("throbber"), gdjs.websiteCode.GDthrobberObjects2);
{gdjs.evtTools.camera.showLayer(runtimeScene, "loadscreen");
}{for(var i = 0, len = gdjs.websiteCode.GDthrobberObjects2.length ;i < len;++i) {
    gdjs.websiteCode.GDthrobberObjects2[i].setCenterPositionInScene(gdjs.evtTools.camera.getCameraX(runtimeScene, "", 0),gdjs.evtTools.camera.getCameraY(runtimeScene, "", 0));
}
}{for(var i = 0, len = gdjs.websiteCode.GDthrobberObjects2.length ;i < len;++i) {
    gdjs.websiteCode.GDthrobberObjects2[i].setAngle(runtimeScene.getGame().getVariables().getFromIndex(0).getChild("throbber angle").getAsNumber());
}
}}

}


{


let isConditionTrue_0 = false;
{

{ //Subevents
gdjs.websiteCode.eventsList1(runtimeScene);} //End of subevents
}

}


{


let isConditionTrue_0 = false;
{
}

}


};gdjs.websiteCode.asyncCallback16157260 = function (runtimeScene, asyncObjectsList) {
asyncObjectsList.restoreLocalVariablesContainers(gdjs.websiteCode.localVariables);
gdjs.copyArray(asyncObjectsList.getObjects("transition_screen"), gdjs.websiteCode.GDtransition_9595screenObjects3);

{gdjs.evtTools.runtimeScene.createObjectsFromExternalLayout(runtimeScene, "home page", 0, 0, 0);
}{for(var i = 0, len = gdjs.websiteCode.GDtransition_9595screenObjects3.length ;i < len;++i) {
    gdjs.websiteCode.GDtransition_9595screenObjects3[i].getBehavior("Tween").addObjectPositionYTween2("clear board", 1920, "easeInQuad", 0.25, false);
}
}gdjs.websiteCode.localVariables.length = 0;
}
gdjs.websiteCode.eventsList3 = function(runtimeScene) {

{


{
{
const asyncObjectsList = new gdjs.LongLivedObjectsList();
asyncObjectsList.backupLocalVariablesContainers(gdjs.websiteCode.localVariables);
for (const obj of gdjs.websiteCode.GDtransition_9595screenObjects2) asyncObjectsList.addObject("transition_screen", obj);
runtimeScene.getAsyncTasksManager().addTask(gdjs.evtTools.runtimeScene.wait(0.26), (runtimeScene) => (gdjs.websiteCode.asyncCallback16157260(runtimeScene, asyncObjectsList)));
}
}

}


};gdjs.websiteCode.eventsList4 = function(runtimeScene) {

{


let isConditionTrue_0 = false;
{
gdjs.copyArray(runtimeScene.getObjects("Body_1"), gdjs.websiteCode.GDBody_95951Objects2);
gdjs.copyArray(runtimeScene.getObjects("Media"), gdjs.websiteCode.GDMediaObjects2);
gdjs.copyArray(gdjs.websiteCode.GDNewPosterObjects1, gdjs.websiteCode.GDNewPosterObjects2);

gdjs.copyArray(runtimeScene.getObjects("email_clipboard"), gdjs.websiteCode.GDemail_9595clipboardObjects2);
gdjs.copyArray(runtimeScene.getObjects("flex_container"), gdjs.websiteCode.GDflex_9595containerObjects2);
gdjs.copyArray(runtimeScene.getObjects("phone_clipboard"), gdjs.websiteCode.GDphone_9595clipboardObjects2);
gdjs.copyArray(runtimeScene.getObjects("press_basic_info"), gdjs.websiteCode.GDpress_9595basic_9595infoObjects2);
gdjs.copyArray(runtimeScene.getObjects("single_line"), gdjs.websiteCode.GDsingle_9595lineObjects2);
gdjs.copyArray(runtimeScene.getObjects("transition_screen"), gdjs.websiteCode.GDtransition_9595screenObjects2);
{for(var i = 0, len = gdjs.websiteCode.GDtransition_9595screenObjects2.length ;i < len;++i) {
    gdjs.websiteCode.GDtransition_9595screenObjects2[i].setY(-(1920));
}
}{for(var i = 0, len = gdjs.websiteCode.GDtransition_9595screenObjects2.length ;i < len;++i) {
    gdjs.websiteCode.GDtransition_9595screenObjects2[i].getBehavior("Tween").addObjectPositionYTween2("clear board", 0, "easeOutQuad", 0.25, false);
}
}{for(var i = 0, len = gdjs.websiteCode.GDBody_95951Objects2.length ;i < len;++i) {
    gdjs.websiteCode.GDBody_95951Objects2[i].deleteFromScene(runtimeScene);
}
for(var i = 0, len = gdjs.websiteCode.GDsingle_9595lineObjects2.length ;i < len;++i) {
    gdjs.websiteCode.GDsingle_9595lineObjects2[i].deleteFromScene(runtimeScene);
}
for(var i = 0, len = gdjs.websiteCode.GDNewPosterObjects2.length ;i < len;++i) {
    gdjs.websiteCode.GDNewPosterObjects2[i].deleteFromScene(runtimeScene);
}
for(var i = 0, len = gdjs.websiteCode.GDflex_9595containerObjects2.length ;i < len;++i) {
    gdjs.websiteCode.GDflex_9595containerObjects2[i].deleteFromScene(runtimeScene);
}
for(var i = 0, len = gdjs.websiteCode.GDemail_9595clipboardObjects2.length ;i < len;++i) {
    gdjs.websiteCode.GDemail_9595clipboardObjects2[i].deleteFromScene(runtimeScene);
}
for(var i = 0, len = gdjs.websiteCode.GDphone_9595clipboardObjects2.length ;i < len;++i) {
    gdjs.websiteCode.GDphone_9595clipboardObjects2[i].deleteFromScene(runtimeScene);
}
for(var i = 0, len = gdjs.websiteCode.GDpress_9595basic_9595infoObjects2.length ;i < len;++i) {
    gdjs.websiteCode.GDpress_9595basic_9595infoObjects2[i].deleteFromScene(runtimeScene);
}
for(var i = 0, len = gdjs.websiteCode.GDMediaObjects2.length ;i < len;++i) {
    gdjs.websiteCode.GDMediaObjects2[i].deleteFromScene(runtimeScene);
}
}
{ //Subevents
gdjs.websiteCode.eventsList3(runtimeScene);} //End of subevents
}

}


};gdjs.websiteCode.eventsList5 = function(runtimeScene) {

{


let isConditionTrue_0 = false;
isConditionTrue_0 = false;
isConditionTrue_0 = gdjs.evtTools.variable.getVariableString(runtimeScene.getScene().getVariables().getFromIndex(2)) != "home";
if (isConditionTrue_0) {
{runtimeScene.getScene().getVariables().getFromIndex(2).setString("home");
}
{ //Subevents
gdjs.websiteCode.eventsList4(runtimeScene);} //End of subevents
}

}


};gdjs.websiteCode.asyncCallback16150852 = function (runtimeScene, asyncObjectsList) {
asyncObjectsList.restoreLocalVariablesContainers(gdjs.websiteCode.localVariables);
gdjs.copyArray(asyncObjectsList.getObjects("transition_screen"), gdjs.websiteCode.GDtransition_9595screenObjects3);

{gdjs.evtTools.runtimeScene.createObjectsFromExternalLayout(runtimeScene, "contact info", 0, 0, 0);
}{for(var i = 0, len = gdjs.websiteCode.GDtransition_9595screenObjects3.length ;i < len;++i) {
    gdjs.websiteCode.GDtransition_9595screenObjects3[i].getBehavior("Tween").addObjectPositionYTween2("clear board", 1920, "easeInQuad", 0.25, false);
}
}gdjs.websiteCode.localVariables.length = 0;
}
gdjs.websiteCode.eventsList6 = function(runtimeScene) {

{


{
{
const asyncObjectsList = new gdjs.LongLivedObjectsList();
asyncObjectsList.backupLocalVariablesContainers(gdjs.websiteCode.localVariables);
for (const obj of gdjs.websiteCode.GDtransition_9595screenObjects2) asyncObjectsList.addObject("transition_screen", obj);
runtimeScene.getAsyncTasksManager().addTask(gdjs.evtTools.runtimeScene.wait(0.26), (runtimeScene) => (gdjs.websiteCode.asyncCallback16150852(runtimeScene, asyncObjectsList)));
}
}

}


};gdjs.websiteCode.eventsList7 = function(runtimeScene) {

{


let isConditionTrue_0 = false;
{
gdjs.copyArray(runtimeScene.getObjects("Body_1"), gdjs.websiteCode.GDBody_95951Objects2);
gdjs.copyArray(runtimeScene.getObjects("Media"), gdjs.websiteCode.GDMediaObjects2);
gdjs.copyArray(gdjs.websiteCode.GDNewPosterObjects1, gdjs.websiteCode.GDNewPosterObjects2);

gdjs.copyArray(runtimeScene.getObjects("email_clipboard"), gdjs.websiteCode.GDemail_9595clipboardObjects2);
gdjs.copyArray(runtimeScene.getObjects("flex_container"), gdjs.websiteCode.GDflex_9595containerObjects2);
gdjs.copyArray(runtimeScene.getObjects("phone_clipboard"), gdjs.websiteCode.GDphone_9595clipboardObjects2);
gdjs.copyArray(runtimeScene.getObjects("press_basic_info"), gdjs.websiteCode.GDpress_9595basic_9595infoObjects2);
gdjs.copyArray(runtimeScene.getObjects("single_line"), gdjs.websiteCode.GDsingle_9595lineObjects2);
gdjs.copyArray(runtimeScene.getObjects("transition_screen"), gdjs.websiteCode.GDtransition_9595screenObjects2);
{for(var i = 0, len = gdjs.websiteCode.GDtransition_9595screenObjects2.length ;i < len;++i) {
    gdjs.websiteCode.GDtransition_9595screenObjects2[i].setY(-(1920));
}
}{for(var i = 0, len = gdjs.websiteCode.GDtransition_9595screenObjects2.length ;i < len;++i) {
    gdjs.websiteCode.GDtransition_9595screenObjects2[i].getBehavior("Tween").addObjectPositionYTween2("clear board", 0, "easeOutQuad", 0.25, false);
}
}{for(var i = 0, len = gdjs.websiteCode.GDBody_95951Objects2.length ;i < len;++i) {
    gdjs.websiteCode.GDBody_95951Objects2[i].deleteFromScene(runtimeScene);
}
for(var i = 0, len = gdjs.websiteCode.GDsingle_9595lineObjects2.length ;i < len;++i) {
    gdjs.websiteCode.GDsingle_9595lineObjects2[i].deleteFromScene(runtimeScene);
}
for(var i = 0, len = gdjs.websiteCode.GDNewPosterObjects2.length ;i < len;++i) {
    gdjs.websiteCode.GDNewPosterObjects2[i].deleteFromScene(runtimeScene);
}
for(var i = 0, len = gdjs.websiteCode.GDflex_9595containerObjects2.length ;i < len;++i) {
    gdjs.websiteCode.GDflex_9595containerObjects2[i].deleteFromScene(runtimeScene);
}
for(var i = 0, len = gdjs.websiteCode.GDemail_9595clipboardObjects2.length ;i < len;++i) {
    gdjs.websiteCode.GDemail_9595clipboardObjects2[i].deleteFromScene(runtimeScene);
}
for(var i = 0, len = gdjs.websiteCode.GDphone_9595clipboardObjects2.length ;i < len;++i) {
    gdjs.websiteCode.GDphone_9595clipboardObjects2[i].deleteFromScene(runtimeScene);
}
for(var i = 0, len = gdjs.websiteCode.GDpress_9595basic_9595infoObjects2.length ;i < len;++i) {
    gdjs.websiteCode.GDpress_9595basic_9595infoObjects2[i].deleteFromScene(runtimeScene);
}
for(var i = 0, len = gdjs.websiteCode.GDMediaObjects2.length ;i < len;++i) {
    gdjs.websiteCode.GDMediaObjects2[i].deleteFromScene(runtimeScene);
}
}
{ //Subevents
gdjs.websiteCode.eventsList6(runtimeScene);} //End of subevents
}

}


};gdjs.websiteCode.eventsList8 = function(runtimeScene) {

{


let isConditionTrue_0 = false;
isConditionTrue_0 = false;
isConditionTrue_0 = gdjs.evtTools.variable.getVariableString(runtimeScene.getScene().getVariables().getFromIndex(2)) != "contact";
if (isConditionTrue_0) {
{runtimeScene.getScene().getVariables().getFromIndex(2).setString("contact");
}
{ //Subevents
gdjs.websiteCode.eventsList7(runtimeScene);} //End of subevents
}

}


};gdjs.websiteCode.asyncCallback10791044 = function (runtimeScene, asyncObjectsList) {
asyncObjectsList.restoreLocalVariablesContainers(gdjs.websiteCode.localVariables);
gdjs.copyArray(asyncObjectsList.getObjects("transition_screen"), gdjs.websiteCode.GDtransition_9595screenObjects2);

{gdjs.evtTools.runtimeScene.createObjectsFromExternalLayout(runtimeScene, "press", 0, 0, 0);
}{for(var i = 0, len = gdjs.websiteCode.GDtransition_9595screenObjects2.length ;i < len;++i) {
    gdjs.websiteCode.GDtransition_9595screenObjects2[i].getBehavior("Tween").addObjectPositionYTween2("clear board", 1920, "easeInQuad", 0.25, false);
}
}gdjs.websiteCode.localVariables.length = 0;
}
gdjs.websiteCode.eventsList9 = function(runtimeScene) {

{


{
{
const asyncObjectsList = new gdjs.LongLivedObjectsList();
asyncObjectsList.backupLocalVariablesContainers(gdjs.websiteCode.localVariables);
for (const obj of gdjs.websiteCode.GDtransition_9595screenObjects1) asyncObjectsList.addObject("transition_screen", obj);
runtimeScene.getAsyncTasksManager().addTask(gdjs.evtTools.runtimeScene.wait(0.26), (runtimeScene) => (gdjs.websiteCode.asyncCallback10791044(runtimeScene, asyncObjectsList)));
}
}

}


};gdjs.websiteCode.eventsList10 = function(runtimeScene) {

{


let isConditionTrue_0 = false;
{
gdjs.copyArray(runtimeScene.getObjects("Body_1"), gdjs.websiteCode.GDBody_95951Objects1);
gdjs.copyArray(runtimeScene.getObjects("Media"), gdjs.websiteCode.GDMediaObjects1);
/* Reuse gdjs.websiteCode.GDNewPosterObjects1 */
gdjs.copyArray(runtimeScene.getObjects("email_clipboard"), gdjs.websiteCode.GDemail_9595clipboardObjects1);
gdjs.copyArray(runtimeScene.getObjects("flex_container"), gdjs.websiteCode.GDflex_9595containerObjects1);
gdjs.copyArray(runtimeScene.getObjects("phone_clipboard"), gdjs.websiteCode.GDphone_9595clipboardObjects1);
gdjs.copyArray(runtimeScene.getObjects("press_basic_info"), gdjs.websiteCode.GDpress_9595basic_9595infoObjects1);
gdjs.copyArray(runtimeScene.getObjects("single_line"), gdjs.websiteCode.GDsingle_9595lineObjects1);
gdjs.copyArray(runtimeScene.getObjects("transition_screen"), gdjs.websiteCode.GDtransition_9595screenObjects1);
{for(var i = 0, len = gdjs.websiteCode.GDtransition_9595screenObjects1.length ;i < len;++i) {
    gdjs.websiteCode.GDtransition_9595screenObjects1[i].setY(-(1920));
}
}{for(var i = 0, len = gdjs.websiteCode.GDtransition_9595screenObjects1.length ;i < len;++i) {
    gdjs.websiteCode.GDtransition_9595screenObjects1[i].getBehavior("Tween").addObjectPositionYTween2("clear board", 0, "easeOutQuad", 0.25, false);
}
}{for(var i = 0, len = gdjs.websiteCode.GDBody_95951Objects1.length ;i < len;++i) {
    gdjs.websiteCode.GDBody_95951Objects1[i].deleteFromScene(runtimeScene);
}
for(var i = 0, len = gdjs.websiteCode.GDsingle_9595lineObjects1.length ;i < len;++i) {
    gdjs.websiteCode.GDsingle_9595lineObjects1[i].deleteFromScene(runtimeScene);
}
for(var i = 0, len = gdjs.websiteCode.GDNewPosterObjects1.length ;i < len;++i) {
    gdjs.websiteCode.GDNewPosterObjects1[i].deleteFromScene(runtimeScene);
}
for(var i = 0, len = gdjs.websiteCode.GDflex_9595containerObjects1.length ;i < len;++i) {
    gdjs.websiteCode.GDflex_9595containerObjects1[i].deleteFromScene(runtimeScene);
}
for(var i = 0, len = gdjs.websiteCode.GDemail_9595clipboardObjects1.length ;i < len;++i) {
    gdjs.websiteCode.GDemail_9595clipboardObjects1[i].deleteFromScene(runtimeScene);
}
for(var i = 0, len = gdjs.websiteCode.GDphone_9595clipboardObjects1.length ;i < len;++i) {
    gdjs.websiteCode.GDphone_9595clipboardObjects1[i].deleteFromScene(runtimeScene);
}
for(var i = 0, len = gdjs.websiteCode.GDpress_9595basic_9595infoObjects1.length ;i < len;++i) {
    gdjs.websiteCode.GDpress_9595basic_9595infoObjects1[i].deleteFromScene(runtimeScene);
}
for(var i = 0, len = gdjs.websiteCode.GDMediaObjects1.length ;i < len;++i) {
    gdjs.websiteCode.GDMediaObjects1[i].deleteFromScene(runtimeScene);
}
}
{ //Subevents
gdjs.websiteCode.eventsList9(runtimeScene);} //End of subevents
}

}


};gdjs.websiteCode.eventsList11 = function(runtimeScene) {

{


let isConditionTrue_0 = false;
isConditionTrue_0 = false;
isConditionTrue_0 = gdjs.evtTools.variable.getVariableString(runtimeScene.getScene().getVariables().getFromIndex(2)) != "press";
if (isConditionTrue_0) {
{runtimeScene.getScene().getVariables().getFromIndex(2).setString("press");
}
{ //Subevents
gdjs.websiteCode.eventsList10(runtimeScene);} //End of subevents
}

}


};gdjs.websiteCode.eventsList12 = function(runtimeScene) {

{

gdjs.copyArray(gdjs.websiteCode.GDNewhamburger_9595menuObjects1, gdjs.websiteCode.GDNewhamburger_9595menuObjects2);


let isConditionTrue_0 = false;
isConditionTrue_0 = false;
for (var i = 0, k = 0, l = gdjs.websiteCode.GDNewhamburger_9595menuObjects2.length;i<l;++i) {
    if ( gdjs.websiteCode.GDNewhamburger_9595menuObjects2[i].IsClickedHome((typeof eventsFunctionContext !== 'undefined' ? eventsFunctionContext : undefined)) ) {
        isConditionTrue_0 = true;
        gdjs.websiteCode.GDNewhamburger_9595menuObjects2[k] = gdjs.websiteCode.GDNewhamburger_9595menuObjects2[i];
        ++k;
    }
}
gdjs.websiteCode.GDNewhamburger_9595menuObjects2.length = k;
if (isConditionTrue_0) {
{gdjs.evtTools.variable.toggleVariableBoolean(runtimeScene.getScene().getVariables().getFromIndex(1));
}
{ //Subevents
gdjs.websiteCode.eventsList5(runtimeScene);} //End of subevents
}

}


{

gdjs.copyArray(gdjs.websiteCode.GDNewhamburger_9595menuObjects1, gdjs.websiteCode.GDNewhamburger_9595menuObjects2);


let isConditionTrue_0 = false;
isConditionTrue_0 = false;
for (var i = 0, k = 0, l = gdjs.websiteCode.GDNewhamburger_9595menuObjects2.length;i<l;++i) {
    if ( gdjs.websiteCode.GDNewhamburger_9595menuObjects2[i].IsClickedContact((typeof eventsFunctionContext !== 'undefined' ? eventsFunctionContext : undefined)) ) {
        isConditionTrue_0 = true;
        gdjs.websiteCode.GDNewhamburger_9595menuObjects2[k] = gdjs.websiteCode.GDNewhamburger_9595menuObjects2[i];
        ++k;
    }
}
gdjs.websiteCode.GDNewhamburger_9595menuObjects2.length = k;
if (isConditionTrue_0) {
{gdjs.evtTools.variable.toggleVariableBoolean(runtimeScene.getScene().getVariables().getFromIndex(1));
}
{ //Subevents
gdjs.websiteCode.eventsList8(runtimeScene);} //End of subevents
}

}


{

/* Reuse gdjs.websiteCode.GDNewhamburger_9595menuObjects1 */

let isConditionTrue_0 = false;
isConditionTrue_0 = false;
for (var i = 0, k = 0, l = gdjs.websiteCode.GDNewhamburger_9595menuObjects1.length;i<l;++i) {
    if ( gdjs.websiteCode.GDNewhamburger_9595menuObjects1[i].IsClickedPress((typeof eventsFunctionContext !== 'undefined' ? eventsFunctionContext : undefined)) ) {
        isConditionTrue_0 = true;
        gdjs.websiteCode.GDNewhamburger_9595menuObjects1[k] = gdjs.websiteCode.GDNewhamburger_9595menuObjects1[i];
        ++k;
    }
}
gdjs.websiteCode.GDNewhamburger_9595menuObjects1.length = k;
if (isConditionTrue_0) {
{gdjs.evtTools.variable.toggleVariableBoolean(runtimeScene.getScene().getVariables().getFromIndex(1));
}
{ //Subevents
gdjs.websiteCode.eventsList11(runtimeScene);} //End of subevents
}

}


};gdjs.websiteCode.eventsList13 = function(runtimeScene) {

{


let isConditionTrue_0 = false;
isConditionTrue_0 = false;
{isConditionTrue_0 = runtimeScene.getOnceTriggers().triggerOnce(11017676);
}
if (isConditionTrue_0) {
gdjs.copyArray(runtimeScene.getObjects("Newhamburger_menu"), gdjs.websiteCode.GDNewhamburger_9595menuObjects2);
{for(var i = 0, len = gdjs.websiteCode.GDNewhamburger_9595menuObjects2.length ;i < len;++i) {
    gdjs.websiteCode.GDNewhamburger_9595menuObjects2[i].hide(false);
}
}}

}


{

gdjs.copyArray(runtimeScene.getObjects("Newhamburger_menu"), gdjs.websiteCode.GDNewhamburger_9595menuObjects1);

let isConditionTrue_0 = false;
isConditionTrue_0 = false;
for (var i = 0, k = 0, l = gdjs.websiteCode.GDNewhamburger_9595menuObjects1.length;i<l;++i) {
    if ( !(gdjs.websiteCode.GDNewhamburger_9595menuObjects1[i].getBehavior("Tween").isPlaying("appear")) ) {
        isConditionTrue_0 = true;
        gdjs.websiteCode.GDNewhamburger_9595menuObjects1[k] = gdjs.websiteCode.GDNewhamburger_9595menuObjects1[i];
        ++k;
    }
}
gdjs.websiteCode.GDNewhamburger_9595menuObjects1.length = k;
if (isConditionTrue_0) {

{ //Subevents
gdjs.websiteCode.eventsList12(runtimeScene);} //End of subevents
}

}


};gdjs.websiteCode.eventsList14 = function(runtimeScene) {

{


let isConditionTrue_0 = false;
isConditionTrue_0 = false;
{isConditionTrue_0 = runtimeScene.getOnceTriggers().triggerOnce(13855156);
}
if (isConditionTrue_0) {
gdjs.copyArray(runtimeScene.getObjects("Newhamburger_menu"), gdjs.websiteCode.GDNewhamburger_9595menuObjects1);
{for(var i = 0, len = gdjs.websiteCode.GDNewhamburger_9595menuObjects1.length ;i < len;++i) {
    gdjs.websiteCode.GDNewhamburger_9595menuObjects1[i].hide();
}
}}

}


};gdjs.websiteCode.eventsList15 = function(runtimeScene) {

{


let isConditionTrue_0 = false;
isConditionTrue_0 = false;
{isConditionTrue_0 = (gdjs.evtTools.window.getWindowInnerWidth() <= gdjs.evtTools.window.getWindowInnerHeight() / 1920 * 928);
}
if (isConditionTrue_0) {
{gdjs.evtTools.window.setGameResolutionResizeMode(runtimeScene, "");
}{gdjs.evtTools.window.setGameResolutionSize(runtimeScene, 928, 1920);
}}

}


{


let isConditionTrue_0 = false;
isConditionTrue_0 = false;
{isConditionTrue_0 = (gdjs.evtTools.window.getWindowInnerWidth() > gdjs.evtTools.window.getWindowInnerHeight() / 1920 * 928);
}
if (isConditionTrue_0) {
{gdjs.evtTools.window.setGameResolutionResizeMode(runtimeScene, "adaptWidth");
}{gdjs.evtTools.window.setGameResolutionSize(runtimeScene, 1920, 1920);
}}

}


{


let isConditionTrue_0 = false;
{
}

}


};gdjs.websiteCode.eventsList16 = function(runtimeScene) {

{

gdjs.copyArray(runtimeScene.getObjects("NewPoster"), gdjs.websiteCode.GDNewPosterObjects2);

let isConditionTrue_0 = false;
isConditionTrue_0 = false;
for (var i = 0, k = 0, l = gdjs.websiteCode.GDNewPosterObjects2.length;i<l;++i) {
    if ( gdjs.websiteCode.GDNewPosterObjects2[i].poster_click((typeof eventsFunctionContext !== 'undefined' ? eventsFunctionContext : undefined)) ) {
        isConditionTrue_0 = true;
        gdjs.websiteCode.GDNewPosterObjects2[k] = gdjs.websiteCode.GDNewPosterObjects2[i];
        ++k;
    }
}
gdjs.websiteCode.GDNewPosterObjects2.length = k;
if (isConditionTrue_0) {
{gdjs.evtTools.window.openURL("https://store.steampowered.com/app/2547140?utm_source=website&utm_medium=web", runtimeScene);
}}

}


{

gdjs.copyArray(runtimeScene.getObjects("steam"), gdjs.websiteCode.GDsteamObjects2);

let isConditionTrue_0 = false;
isConditionTrue_0 = false;
for (var i = 0, k = 0, l = gdjs.websiteCode.GDsteamObjects2.length;i<l;++i) {
    if ( gdjs.websiteCode.GDsteamObjects2[i].getBehavior("ButtonFSM").IsClicked((typeof eventsFunctionContext !== 'undefined' ? eventsFunctionContext : undefined)) ) {
        isConditionTrue_0 = true;
        gdjs.websiteCode.GDsteamObjects2[k] = gdjs.websiteCode.GDsteamObjects2[i];
        ++k;
    }
}
gdjs.websiteCode.GDsteamObjects2.length = k;
if (isConditionTrue_0) {
{gdjs.evtTools.window.openURL("https://store.steampowered.com/curator/44609576", runtimeScene);
}}

}


{

gdjs.copyArray(runtimeScene.getObjects("Youtube"), gdjs.websiteCode.GDYoutubeObjects2);

let isConditionTrue_0 = false;
isConditionTrue_0 = false;
for (var i = 0, k = 0, l = gdjs.websiteCode.GDYoutubeObjects2.length;i<l;++i) {
    if ( gdjs.websiteCode.GDYoutubeObjects2[i].getBehavior("ButtonFSM").IsClicked((typeof eventsFunctionContext !== 'undefined' ? eventsFunctionContext : undefined)) ) {
        isConditionTrue_0 = true;
        gdjs.websiteCode.GDYoutubeObjects2[k] = gdjs.websiteCode.GDYoutubeObjects2[i];
        ++k;
    }
}
gdjs.websiteCode.GDYoutubeObjects2.length = k;
if (isConditionTrue_0) {
{gdjs.evtTools.window.openURL("https://www.youtube.com/@fuzzystudios01", runtimeScene);
}}

}


{

gdjs.copyArray(runtimeScene.getObjects("Twitter"), gdjs.websiteCode.GDTwitterObjects2);

let isConditionTrue_0 = false;
isConditionTrue_0 = false;
for (var i = 0, k = 0, l = gdjs.websiteCode.GDTwitterObjects2.length;i<l;++i) {
    if ( gdjs.websiteCode.GDTwitterObjects2[i].getBehavior("ButtonFSM").IsClicked((typeof eventsFunctionContext !== 'undefined' ? eventsFunctionContext : undefined)) ) {
        isConditionTrue_0 = true;
        gdjs.websiteCode.GDTwitterObjects2[k] = gdjs.websiteCode.GDTwitterObjects2[i];
        ++k;
    }
}
gdjs.websiteCode.GDTwitterObjects2.length = k;
if (isConditionTrue_0) {
{gdjs.evtTools.window.openURL("https://x.com/fuzzystudios1", runtimeScene);
}}

}


{

gdjs.copyArray(runtimeScene.getObjects("Media"), gdjs.websiteCode.GDMediaObjects2);

let isConditionTrue_0 = false;
isConditionTrue_0 = false;
for (var i = 0, k = 0, l = gdjs.websiteCode.GDMediaObjects2.length;i<l;++i) {
    if ( gdjs.websiteCode.GDMediaObjects2[i].IsClicked((typeof eventsFunctionContext !== 'undefined' ? eventsFunctionContext : undefined)) ) {
        isConditionTrue_0 = true;
        gdjs.websiteCode.GDMediaObjects2[k] = gdjs.websiteCode.GDMediaObjects2[i];
        ++k;
    }
}
gdjs.websiteCode.GDMediaObjects2.length = k;
if (isConditionTrue_0) {
{gdjs.evtTools.window.openURL("https://drive.google.com/drive/folders/1ZlWkb-syIZmPkwH6i_2lFzx2n8MqiotR?usp=sharing", runtimeScene);
}}

}


{

gdjs.copyArray(runtimeScene.getObjects("clipboard_icon"), gdjs.websiteCode.GDclipboard_9595iconObjects1);

let isConditionTrue_0 = false;
isConditionTrue_0 = false;
for (var i = 0, k = 0, l = gdjs.websiteCode.GDclipboard_9595iconObjects1.length;i<l;++i) {
    if ( gdjs.websiteCode.GDclipboard_9595iconObjects1[i].getBehavior("ButtonFSM").IsClicked((typeof eventsFunctionContext !== 'undefined' ? eventsFunctionContext : undefined)) ) {
        isConditionTrue_0 = true;
        gdjs.websiteCode.GDclipboard_9595iconObjects1[k] = gdjs.websiteCode.GDclipboard_9595iconObjects1[i];
        ++k;
    }
}
gdjs.websiteCode.GDclipboard_9595iconObjects1.length = k;
if (isConditionTrue_0) {
/* Reuse gdjs.websiteCode.GDclipboard_9595iconObjects1 */
{gdjs.evtsExt__Clipboard__WriteText.func(runtimeScene, ((gdjs.websiteCode.GDclipboard_9595iconObjects1.length === 0 ) ? gdjs.VariablesContainer.badVariablesContainer : gdjs.websiteCode.GDclipboard_9595iconObjects1[0].getVariables()).getFromIndex(0).getAsString(), (typeof eventsFunctionContext !== 'undefined' ? eventsFunctionContext : undefined));
}}

}


};gdjs.websiteCode.mapOfEmptyGDflex_9595containerObjects = Hashtable.newFrom({"flex_container": []});
gdjs.websiteCode.eventsList17 = function(runtimeScene) {

{


let isConditionTrue_0 = false;
isConditionTrue_0 = false;
isConditionTrue_0 = gdjs.evtTools.runtimeScene.sceneJustBegins(runtimeScene);
if (isConditionTrue_0) {

{ //Subevents
gdjs.websiteCode.eventsList2(runtimeScene);} //End of subevents
}

}


{



}


{


let isConditionTrue_0 = false;
{
gdjs.copyArray(runtimeScene.getObjects("press_basic_info"), gdjs.websiteCode.GDpress_9595basic_9595infoObjects1);
{for(var i = 0, len = gdjs.websiteCode.GDpress_9595basic_9595infoObjects1.length ;i < len;++i) {
    gdjs.websiteCode.GDpress_9595basic_9595infoObjects1[i].reconf_clipboard(runtimeScene.getScene().getVariables().getFromIndex(4).getAsString(), (typeof eventsFunctionContext !== 'undefined' ? eventsFunctionContext : undefined));
}
}}

}


{

gdjs.copyArray(runtimeScene.getObjects("clipboard_icon"), gdjs.websiteCode.GDclipboard_9595iconObjects1);
gdjs.copyArray(runtimeScene.getObjects("single_line"), gdjs.websiteCode.GDsingle_9595lineObjects1);

let isConditionTrue_0 = false;
isConditionTrue_0 = false;
for (var i = 0, k = 0, l = gdjs.websiteCode.GDclipboard_9595iconObjects1.length;i<l;++i) {
    if ( gdjs.websiteCode.GDclipboard_9595iconObjects1[i].getVariableNumber(gdjs.websiteCode.GDclipboard_9595iconObjects1[i].getVariables().getFromIndex(1)) == ((gdjs.websiteCode.GDsingle_9595lineObjects1.length === 0 ) ? gdjs.VariablesContainer.badVariablesContainer : gdjs.websiteCode.GDsingle_9595lineObjects1[0].getVariables()).getFromIndex(1).getAsNumber() ) {
        isConditionTrue_0 = true;
        gdjs.websiteCode.GDclipboard_9595iconObjects1[k] = gdjs.websiteCode.GDclipboard_9595iconObjects1[i];
        ++k;
    }
}
gdjs.websiteCode.GDclipboard_9595iconObjects1.length = k;
if (isConditionTrue_0) {
/* Reuse gdjs.websiteCode.GDclipboard_9595iconObjects1 */
/* Reuse gdjs.websiteCode.GDsingle_9595lineObjects1 */
{for(var i = 0, len = gdjs.websiteCode.GDclipboard_9595iconObjects1.length ;i < len;++i) {
    gdjs.websiteCode.GDclipboard_9595iconObjects1[i].setY((( gdjs.websiteCode.GDsingle_9595lineObjects1.length === 0 ) ? 0 :gdjs.websiteCode.GDsingle_9595lineObjects1[0].getY()));
}
}}

}


{


let isConditionTrue_0 = false;
{
gdjs.copyArray(runtimeScene.getObjects("throbber"), gdjs.websiteCode.GDthrobberObjects1);
{for(var i = 0, len = gdjs.websiteCode.GDthrobberObjects1.length ;i < len;++i) {
    gdjs.websiteCode.GDthrobberObjects1[i].setCenterPositionInScene(gdjs.evtTools.camera.getCameraX(runtimeScene, (gdjs.websiteCode.GDthrobberObjects1[i].getLayer()), 0),gdjs.evtTools.camera.getCameraY(runtimeScene, (gdjs.websiteCode.GDthrobberObjects1[i].getLayer()), 0));
}
}{for(var i = 0, len = gdjs.websiteCode.GDthrobberObjects1.length ;i < len;++i) {
    gdjs.websiteCode.GDthrobberObjects1[i].rotate(90, runtimeScene);
}
}}

}


{

gdjs.copyArray(runtimeScene.getObjects("menu_button"), gdjs.websiteCode.GDmenu_9595buttonObjects1);

let isConditionTrue_0 = false;
isConditionTrue_0 = false;
for (var i = 0, k = 0, l = gdjs.websiteCode.GDmenu_9595buttonObjects1.length;i<l;++i) {
    if ( gdjs.websiteCode.GDmenu_9595buttonObjects1[i].getBehavior("ButtonFSM").IsClicked((typeof eventsFunctionContext !== 'undefined' ? eventsFunctionContext : undefined)) ) {
        isConditionTrue_0 = true;
        gdjs.websiteCode.GDmenu_9595buttonObjects1[k] = gdjs.websiteCode.GDmenu_9595buttonObjects1[i];
        ++k;
    }
}
gdjs.websiteCode.GDmenu_9595buttonObjects1.length = k;
if (isConditionTrue_0) {
{gdjs.evtTools.variable.toggleVariableBoolean(runtimeScene.getScene().getVariables().getFromIndex(1));
}}

}


{


let isConditionTrue_0 = false;
isConditionTrue_0 = false;
isConditionTrue_0 = gdjs.evtTools.variable.getVariableBoolean(runtimeScene.getScene().getVariables().getFromIndex(1), true, false);
if (isConditionTrue_0) {
gdjs.copyArray(runtimeScene.getObjects("NewPoster"), gdjs.websiteCode.GDNewPosterObjects1);
{for(var i = 0, len = gdjs.websiteCode.GDNewPosterObjects1.length ;i < len;++i) {
    gdjs.websiteCode.GDNewPosterObjects1[i].disable_click((typeof eventsFunctionContext !== 'undefined' ? eventsFunctionContext : undefined));
}
}
{ //Subevents
gdjs.websiteCode.eventsList13(runtimeScene);} //End of subevents
}

}


{


let isConditionTrue_0 = false;
isConditionTrue_0 = false;
isConditionTrue_0 = gdjs.evtTools.variable.getVariableBoolean(runtimeScene.getScene().getVariables().getFromIndex(1), false, false);
if (isConditionTrue_0) {
gdjs.copyArray(runtimeScene.getObjects("NewPoster"), gdjs.websiteCode.GDNewPosterObjects1);
{for(var i = 0, len = gdjs.websiteCode.GDNewPosterObjects1.length ;i < len;++i) {
    gdjs.websiteCode.GDNewPosterObjects1[i].enable_click((typeof eventsFunctionContext !== 'undefined' ? eventsFunctionContext : undefined));
}
}
{ //Subevents
gdjs.websiteCode.eventsList14(runtimeScene);} //End of subevents
}

}


{


gdjs.websiteCode.eventsList15(runtimeScene);
}


{


gdjs.websiteCode.eventsList16(runtimeScene);
}


{



}


{


let isConditionTrue_0 = false;
isConditionTrue_0 = false;
isConditionTrue_0 = gdjs.evtTools.object.getSceneInstancesCount((typeof eventsFunctionContext !== 'undefined' ? eventsFunctionContext : runtimeScene), gdjs.websiteCode.mapOfEmptyGDflex_9595containerObjects) > 0;
if (isConditionTrue_0) {
gdjs.copyArray(runtimeScene.getObjects("flex_container"), gdjs.websiteCode.GDflex_9595containerObjects1);
{gdjs.evtTools.camera.setCameraX(runtimeScene, (( gdjs.websiteCode.GDflex_9595containerObjects1.length === 0 ) ? 0 :gdjs.websiteCode.GDflex_9595containerObjects1[0].getCenterXInScene()), "", 0);
}}

}


{

gdjs.copyArray(runtimeScene.getObjects("Newhamburger_menu"), gdjs.websiteCode.GDNewhamburger_9595menuObjects1);
gdjs.copyArray(runtimeScene.getObjects("menu_backing"), gdjs.websiteCode.GDmenu_9595backingObjects1);

let isConditionTrue_0 = false;
isConditionTrue_0 = false;
isConditionTrue_0 = gdjs.evtTools.variable.getVariableNumber(runtimeScene.getScene().getVariables().getFromIndex(3)) != (( gdjs.websiteCode.GDmenu_9595backingObjects1.length === 0 ) ? 0 :gdjs.websiteCode.GDmenu_9595backingObjects1[0].getWidth());
if (isConditionTrue_0) {
isConditionTrue_0 = false;
for (var i = 0, k = 0, l = gdjs.websiteCode.GDNewhamburger_9595menuObjects1.length;i<l;++i) {
    if ( !(gdjs.websiteCode.GDNewhamburger_9595menuObjects1[i].isVisible()) ) {
        isConditionTrue_0 = true;
        gdjs.websiteCode.GDNewhamburger_9595menuObjects1[k] = gdjs.websiteCode.GDNewhamburger_9595menuObjects1[i];
        ++k;
    }
}
gdjs.websiteCode.GDNewhamburger_9595menuObjects1.length = k;
}
if (isConditionTrue_0) {
/* Reuse gdjs.websiteCode.GDNewhamburger_9595menuObjects1 */
/* Reuse gdjs.websiteCode.GDmenu_9595backingObjects1 */
{for(var i = 0, len = gdjs.websiteCode.GDNewhamburger_9595menuObjects1.length ;i < len;++i) {
    gdjs.websiteCode.GDNewhamburger_9595menuObjects1[i].getBehavior("Resizable").setWidth((( gdjs.websiteCode.GDmenu_9595backingObjects1.length === 0 ) ? 0 :gdjs.websiteCode.GDmenu_9595backingObjects1[0].getWidth()));
}
}{runtimeScene.getScene().getVariables().getFromIndex(3).setNumber((( gdjs.websiteCode.GDmenu_9595backingObjects1.length === 0 ) ? 0 :gdjs.websiteCode.GDmenu_9595backingObjects1[0].getWidth()));
}}

}


};

gdjs.websiteCode.func = function(runtimeScene) {
runtimeScene.getOnceTriggers().startNewFrame();

gdjs.websiteCode.GDTwitterObjects1.length = 0;
gdjs.websiteCode.GDTwitterObjects2.length = 0;
gdjs.websiteCode.GDTwitterObjects3.length = 0;
gdjs.websiteCode.GDTwitterObjects4.length = 0;
gdjs.websiteCode.GDTwitterObjects5.length = 0;
gdjs.websiteCode.GDYoutubeObjects1.length = 0;
gdjs.websiteCode.GDYoutubeObjects2.length = 0;
gdjs.websiteCode.GDYoutubeObjects3.length = 0;
gdjs.websiteCode.GDYoutubeObjects4.length = 0;
gdjs.websiteCode.GDYoutubeObjects5.length = 0;
gdjs.websiteCode.GDwebsite_9595nameObjects1.length = 0;
gdjs.websiteCode.GDwebsite_9595nameObjects2.length = 0;
gdjs.websiteCode.GDwebsite_9595nameObjects3.length = 0;
gdjs.websiteCode.GDwebsite_9595nameObjects4.length = 0;
gdjs.websiteCode.GDwebsite_9595nameObjects5.length = 0;
gdjs.websiteCode.GDsteamObjects1.length = 0;
gdjs.websiteCode.GDsteamObjects2.length = 0;
gdjs.websiteCode.GDsteamObjects3.length = 0;
gdjs.websiteCode.GDsteamObjects4.length = 0;
gdjs.websiteCode.GDsteamObjects5.length = 0;
gdjs.websiteCode.GDBody_95951Objects1.length = 0;
gdjs.websiteCode.GDBody_95951Objects2.length = 0;
gdjs.websiteCode.GDBody_95951Objects3.length = 0;
gdjs.websiteCode.GDBody_95951Objects4.length = 0;
gdjs.websiteCode.GDBody_95951Objects5.length = 0;
gdjs.websiteCode.GDtext_9595body_9595referenceObjects1.length = 0;
gdjs.websiteCode.GDtext_9595body_9595referenceObjects2.length = 0;
gdjs.websiteCode.GDtext_9595body_9595referenceObjects3.length = 0;
gdjs.websiteCode.GDtext_9595body_9595referenceObjects4.length = 0;
gdjs.websiteCode.GDtext_9595body_9595referenceObjects5.length = 0;
gdjs.websiteCode.GDmenu_9595buttonObjects1.length = 0;
gdjs.websiteCode.GDmenu_9595buttonObjects2.length = 0;
gdjs.websiteCode.GDmenu_9595buttonObjects3.length = 0;
gdjs.websiteCode.GDmenu_9595buttonObjects4.length = 0;
gdjs.websiteCode.GDmenu_9595buttonObjects5.length = 0;
gdjs.websiteCode.GDtemplateObjects1.length = 0;
gdjs.websiteCode.GDtemplateObjects2.length = 0;
gdjs.websiteCode.GDtemplateObjects3.length = 0;
gdjs.websiteCode.GDtemplateObjects4.length = 0;
gdjs.websiteCode.GDtemplateObjects5.length = 0;
gdjs.websiteCode.GDNewButtonObjects1.length = 0;
gdjs.websiteCode.GDNewButtonObjects2.length = 0;
gdjs.websiteCode.GDNewButtonObjects3.length = 0;
gdjs.websiteCode.GDNewButtonObjects4.length = 0;
gdjs.websiteCode.GDNewButtonObjects5.length = 0;
gdjs.websiteCode.GDsingle_9595lineObjects1.length = 0;
gdjs.websiteCode.GDsingle_9595lineObjects2.length = 0;
gdjs.websiteCode.GDsingle_9595lineObjects3.length = 0;
gdjs.websiteCode.GDsingle_9595lineObjects4.length = 0;
gdjs.websiteCode.GDsingle_9595lineObjects5.length = 0;
gdjs.websiteCode.GDmenu_9595backingObjects1.length = 0;
gdjs.websiteCode.GDmenu_9595backingObjects2.length = 0;
gdjs.websiteCode.GDmenu_9595backingObjects3.length = 0;
gdjs.websiteCode.GDmenu_9595backingObjects4.length = 0;
gdjs.websiteCode.GDmenu_9595backingObjects5.length = 0;
gdjs.websiteCode.GDclipboard_9595iconObjects1.length = 0;
gdjs.websiteCode.GDclipboard_9595iconObjects2.length = 0;
gdjs.websiteCode.GDclipboard_9595iconObjects3.length = 0;
gdjs.websiteCode.GDclipboard_9595iconObjects4.length = 0;
gdjs.websiteCode.GDclipboard_9595iconObjects5.length = 0;
gdjs.websiteCode.GDtransition_9595screenObjects1.length = 0;
gdjs.websiteCode.GDtransition_9595screenObjects2.length = 0;
gdjs.websiteCode.GDtransition_9595screenObjects3.length = 0;
gdjs.websiteCode.GDtransition_9595screenObjects4.length = 0;
gdjs.websiteCode.GDtransition_9595screenObjects5.length = 0;
gdjs.websiteCode.GDflex_9595containerObjects1.length = 0;
gdjs.websiteCode.GDflex_9595containerObjects2.length = 0;
gdjs.websiteCode.GDflex_9595containerObjects3.length = 0;
gdjs.websiteCode.GDflex_9595containerObjects4.length = 0;
gdjs.websiteCode.GDflex_9595containerObjects5.length = 0;
gdjs.websiteCode.GDemail_9595clipboardObjects1.length = 0;
gdjs.websiteCode.GDemail_9595clipboardObjects2.length = 0;
gdjs.websiteCode.GDemail_9595clipboardObjects3.length = 0;
gdjs.websiteCode.GDemail_9595clipboardObjects4.length = 0;
gdjs.websiteCode.GDemail_9595clipboardObjects5.length = 0;
gdjs.websiteCode.GDphone_9595clipboardObjects1.length = 0;
gdjs.websiteCode.GDphone_9595clipboardObjects2.length = 0;
gdjs.websiteCode.GDphone_9595clipboardObjects3.length = 0;
gdjs.websiteCode.GDphone_9595clipboardObjects4.length = 0;
gdjs.websiteCode.GDphone_9595clipboardObjects5.length = 0;
gdjs.websiteCode.GDNewPosterObjects1.length = 0;
gdjs.websiteCode.GDNewPosterObjects2.length = 0;
gdjs.websiteCode.GDNewPosterObjects3.length = 0;
gdjs.websiteCode.GDNewPosterObjects4.length = 0;
gdjs.websiteCode.GDNewPosterObjects5.length = 0;
gdjs.websiteCode.GDNewhamburger_9595menuObjects1.length = 0;
gdjs.websiteCode.GDNewhamburger_9595menuObjects2.length = 0;
gdjs.websiteCode.GDNewhamburger_9595menuObjects3.length = 0;
gdjs.websiteCode.GDNewhamburger_9595menuObjects4.length = 0;
gdjs.websiteCode.GDNewhamburger_9595menuObjects5.length = 0;
gdjs.websiteCode.GDpress_9595basic_9595infoObjects1.length = 0;
gdjs.websiteCode.GDpress_9595basic_9595infoObjects2.length = 0;
gdjs.websiteCode.GDpress_9595basic_9595infoObjects3.length = 0;
gdjs.websiteCode.GDpress_9595basic_9595infoObjects4.length = 0;
gdjs.websiteCode.GDpress_9595basic_9595infoObjects5.length = 0;
gdjs.websiteCode.GDMediaObjects1.length = 0;
gdjs.websiteCode.GDMediaObjects2.length = 0;
gdjs.websiteCode.GDMediaObjects3.length = 0;
gdjs.websiteCode.GDMediaObjects4.length = 0;
gdjs.websiteCode.GDMediaObjects5.length = 0;
gdjs.websiteCode.GDloadscreenObjects1.length = 0;
gdjs.websiteCode.GDloadscreenObjects2.length = 0;
gdjs.websiteCode.GDloadscreenObjects3.length = 0;
gdjs.websiteCode.GDloadscreenObjects4.length = 0;
gdjs.websiteCode.GDloadscreenObjects5.length = 0;
gdjs.websiteCode.GDthrobberObjects1.length = 0;
gdjs.websiteCode.GDthrobberObjects2.length = 0;
gdjs.websiteCode.GDthrobberObjects3.length = 0;
gdjs.websiteCode.GDthrobberObjects4.length = 0;
gdjs.websiteCode.GDthrobberObjects5.length = 0;

gdjs.websiteCode.eventsList17(runtimeScene);

return;

}

gdjs['websiteCode'] = gdjs.websiteCode;
